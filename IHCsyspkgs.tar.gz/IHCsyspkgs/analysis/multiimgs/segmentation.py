help=""" to convert the image into gray one and then do segmentation by superpixel."""
import sys,string,os
import cv
import cv2

class dowork:

	def __init__(self,inputf,paraf):
		self.inputf=inputf
		self.paraf=paraf
		prefix=self.inputf.split('.')
		self.outf=prefix[0]+'.pgm'
		self.spoutf=prefix[0]+'_segout.ppm'
	
	def getpara(self):
		f=open(self.paraf,'r')
		data=f.readlines()
		for i in range(len(data)):
			word=data[i][:-1].split()
			if word[0]=='superpath':
				self.sppath=word[1]
			if word[0]=='patchsize':
				self.patchsize=word[1]
			if word[0]=='numinsp':
				self.numinsp=word[1]

	def converting(self):
		img=cv.LoadImage(self.inputf)
		size=cv.GetSize(img)
		grey=cv.CreateImage(size,8,1)# channel=1 means grey
		cv.CvtColor(img,grey,cv.CV_BGR2GRAY)
		cv.SaveImage(self.outf,grey)

	def segment(self):
		cmd=self.sppath+'superpixels '+self.outf+' '+self.spoutf+' '+self.patchsize+'*'+self.patchsize+' '+self.numinsp
		os.system(cmd)


f=open(sys.argv[1],'r')# the pnglist file
dataf=f.readlines()
for i in range(len(dataf)):
	doit=dowork(dataf[i][:-1],sys.argv[2]) # parameter.txt
	doit.getpara()
	doit.converting()
	doit.segment()		
