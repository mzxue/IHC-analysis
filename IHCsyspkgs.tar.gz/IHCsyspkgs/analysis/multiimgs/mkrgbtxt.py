help=""" to list all rgb.txt in each folder by each image."""
import sys,os,string

f=open(sys.argv[1],'r')# pnglist.txt file
dataf=f.readlines()

f1=open(sys.argv[2],'r')# parameter.txt file
paras=f1.readlines()
for i in range(len(paras)):
	word=paras[i][:-1].split()
	if word[0]=='patchpath':
		patchpath=word[1]

pwd=os.getcwd()
for i in range(len(dataf)):
	word=dataf[i][:-1].split('.')
	cmd='ls '+pwd+'/'+patchpath+'/'+word[0]+'_segout/*rgb.txt > '+word[0]+'_rgblist.txt'
	os.system(cmd)
