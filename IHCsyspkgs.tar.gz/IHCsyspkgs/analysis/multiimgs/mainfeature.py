help=""" to main featurecom and combinefea."""
import os,sys,string

f1=open(sys.argv[1],'r')# the rgblist.txt file
dataf=f1.readlines()

for i in range(len(dataf)):
	cmd='python featurecom.py '+dataf[i][:-1]+' '+sys.argv[2] # parameter.txt
	os.system(cmd)
	cmd2='python combinefea.py '+dataf[i][:-1]
	os.system(cmd2)
