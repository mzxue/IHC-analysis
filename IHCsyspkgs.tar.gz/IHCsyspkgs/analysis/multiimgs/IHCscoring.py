help=""" to select features according to feature selection results, combine Superpatch, do classification prediction and display cancer patches with score and positive rate."""
import sys,os,string
import Image,ImageColor,ImageFilter
from ImageColor import getrgb
from sklearn import svm

def mkweight(data):
	distance=[]
	for i in range(len(data)):
		word=data[i][:-1].split()
		distance.append(float(word[1]))
	weights=[]
	for i in range(len(distance)):
		weight=distance[i]*1.0/sum(distance)
		weights.append(weight)
	return weights

def mksuperp(imagebin,weights,imagename):
	allpatch=[]
	for i in range(len(imagebin)):
		term=imagebin[i][:-1].split()
		newfeas=[]
		for nn in range(len(term[1:])):
			eachfea=float(term[1+nn])*float(weights[i])
			newfeas.append(eachfea)
		allpatch.append(newfeas)
	newline=imagename+' '
	combinefeas=[]
	for j in range(len(allpatch[0])):
		combinefea=0
		for i in range(len(allpatch)):
			combinefea+=allpatch[i][j]
		combinefeas.append(str(combinefea))
	features=' '.join(combinefeas)
	newline+=features
	return newline

class scoring:

	def __init__(self,indexf,allpatchf,cosdisf,modelf,labelf,pngf,rgblist,outpath):
		self.indexf=indexf # the optimal index of features after feature selection
		self.allpatchf=allpatchf # xx_allpatchfeature.txt
		name=self.allpatchf.split('_')
		self.feaseloutf=name[0]+'_feaselcancer.txt'
		self.cosdisf=cosdisf # xx_potentialcancer_adjcos.dis
		self.modelf=modelf # model for LSVM
		self.labelf=labelf # model-label file
		self.pngf=pngf # the original png file
		img=self.pngf.split('.')
		self.imgname=img[0]
		self.superpresf=name[0]+'_superp_feasel.txt'
		self.rgblist=rgblist # xx_rgbtxt.list
		self.scoreoutf=name[0]+'scorebyLSVC.txt'
		self.rgbcanf=self.imgname+'_cancerpatch_rgb.txt'
		self.candisplay=self.imgname+'_cancerpatch.png'
		self.outpath=outpath # to store results

	def feasel(self):
		# to get potential cancer patches feature data
		f1=open(self.allpatchf,'r')
		data=f1.readlines()
		self.patchtotal=len(data)
		f3=open(self.cosdisf,'r')
		f3.readline()
		self.cosdata=f3.readlines()
		self.positive=len(self.cosdata)
		self.cancerpatch=[]
		for i in range(len(self.cosdata)):
			patchname=self.cosdata[i][:-1].split()
			self.cancerpatch.append(patchname[0])
		self.cancerdata=[]
		for i in range(len(data)):
			word=data[i][:-1].split()
			if word[0] in self.cancerpatch:
				self.cancerdata.append(data[i][:-1])
		# to get optimal feature vector
		f2=open(self.indexf,'r')
		f2.readline()
		index=f2.readlines()
		hitindex=[]
		for i in range(len(index)):
			word=index[i][:-1].split()
			hitindex.append(int(word[0]))
		fout=open(self.feaseloutf,'w')
		for i in range(len(self.cancerdata)):
			term=self.cancerdata[i].split()
			fout.write(term[0]+' ')
			for nn in hitindex:
				fout.write(term[1+nn]+' ')
			fout.write('\n')
		fout.close()

	def superpatch(self):
		self.weights=mkweight(self.cosdata)
		f=open(self.feaseloutf,'r')
		data=f.readlines()
		self.superp=mksuperp(data,self.weights,self.imgname)
		fout=open(self.superpresf,'w')
		fout.write(self.superp+'\n')
		fout.close()

	def machlearn(self):
		f=open(self.modelf,'r')
		trains=f.readlines()
		self.modeldata=[]
		for i in range(len(trains)):
			word=trains[i][:-1].split()
			archive=[]
			for nn in word[1:]:
				archive.append(float(nn))
			self.modeldata.append(archive)
		f1=open(self.labelf,'r')
		alllabel=f1.readlines()
		self.labels=[]
		for i in range(len(alllabel)):
			term=alllabel[i][:-1].split()
			self.labels.append(int(term[2]))	
		clf3=svm.LinearSVC()
		model3=clf3.fit(self.modeldata,self.labels)
		f2=open(self.superpresf,'r')
		data=f2.readlines()
		self.guestdata=[]
		for i in range(len(data)):
			word=data[i][:-1].split()
			archive=[]
			for mm in word[1:]:
				archive.append(float(mm))
			self.guestdata.append(archive)
		self.predict=model3.predict(self.guestdata)
		self.positiverate=self.positive*100.0/self.patchtotal
		fout=open(self.outpath+self.scoreoutf,'w')
		fout.write(self.imgname+'\n')
		fout.write('predicted_class ')
		if self.predict[0]=='0':
			fout.write('0 negative\n')
		else:
			fout.write(str(self.predict[0])+' positive'+str(self.predict[0])+'\n')
		fout.write('representative_positive_rate(%) '+str(self.positiverate)+'\n') 
		fout.close()

	def displayit(self):
		f=open(self.rgblist,'r')					
		allf=f.readlines()
		patchallf=[]
		cancerf=[]
		for i in range(len(allf)):
			word=allf[i].split('/')
			term=word[-1].split('_')
			name=term[0]+'_'+term[1]
			if name in self.cancerpatch:
				cancerf.append(allf[i][:-1])
		cmd='cat '
		for i in range(len(cancerf)):
			cmd+=cancerf[i]+' '
		cmd+=' > '+self.rgbcanf
		os.system(cmd)
		
		f1=open(self.rgbcanf,'r')
		rgball=f1.readlines()
		bgcolor=Image.open(self.pngf)
		newimg=bgcolor.filter(ImageFilter.CONTOUR)
		positions=[]
		rgbs=[]
		for i in range(len(rgball)):
			term=rgball[i][:-1].split(')')
			number=term[0].split('(')
			renumber=number[1].split(',')
			point=(int(renumber[0]),int(renumber[1]))
			positions.append(point)
			rgbs.append(term[1][1:]+')')

		for i in range(len(rgball)):
			pixel=Image.new('RGB',(1,1),getrgb(rgbs[i]))
			newimg.paste(pixel,positions[i])
		newimg.save(self.outpath+self.candisplay)
		
outpath='results/'
cmd='mkdir '+outpath
if not os.path.exists(outpath):
	os.system(cmd)

f=open(sys.argv[1],'r')# the pnglist file
dataf=f.readlines()
f2=open(sys.argv[2],'r')# the rgblist.txt file
rgbfs=f2.readlines()
for i in range(len(dataf)):
	word=dataf[i][:-1].split('.')
	patchf=word[0]+'_allpatchfeature.txt'
	cosdisf=word[0]+'_potentialcancer_adjcos.dis'
	judgement=scoring(sys.argv[3],patchf,cosdisf,sys.argv[4],sys.argv[5],dataf[i][:-1],rgbfs[i][:-1],outpath)
	judgement.feasel()
	judgement.superpatch()
	judgement.machlearn()
	judgement.displayit()			
		
