help=""" to calculate adjusted cos distance of each patch to ones in the positive set for each image."""
import sys,string,math
import numpy as np
import Image

class Rand_idx:
	def __init__(self,rank,idx):
		self.rank=rank
		self.idx=idx

def compare(r1,r2):
	if float(r1.rank) < float(r2.rank):
		return 1
	if float(r1.rank) == float(r2.rank):
		return 0
	if float(r1.rank) > float(r2.rank):
		return -1

class dowork:
	def __init__(self,imf,posif):
		self.imf=imf
		self.posif=posif
		
	def readf(self):
		f=open(self.imf,'r')# each image data file
		imdata=f.readlines()
		f1=open(self.posif,'r')# positive data file
		cancer=f1.readlines()
		self.patches=[]
		self.positive=[]
		for i in range(len(imdata)):
			word=imdata[i][:-1].split()
			archive=[]
			for nn in word:
				archive.append(nn)
			self.patches.append(archive)
		for i in range(len(cancer)):
			word=cancer[i][:-1].split()
			self.feanumber=len(word)
			archive=[]
			for mm in word:
				archive.append(mm)			
			self.positive.append(archive)
	
	def featuredist(self):
		self.meandis=[]		
		self.meanfeature=[]
		self.meanfeature.append('mean')
		for j in range(self.feanumber):
			if j ==0:
				continue
			else:
				sum_eachfea=0
				for i in range(len(self.patches)):
					sum_eachfea+=float(self.patches[i][j])
				for n in range(len(self.positive)):
					sum_eachfea+=float(self.positive[n][j])
				mean_eachfea=sum_eachfea/(len(self.patches)+len(self.positive))
				self.meanfeature.append(mean_eachfea) 		
		for i in range(len(self.patches)):
			archive=[]
			out=[]			
			out.append(self.patches[i][0])			
			for n in range(len(self.positive)):				
				sum_ab=0
				sum_as2=0
				sum_bs2=0
				for j in range(len(self.patches[i])):
					if j ==0:						
						continue
					else:	
						sum_ab+=(float(self.patches[i][j])-self.meanfeature[j])*(float(self.positive[n][j])-self.meanfeature[j])
						sum_as2+=pow((float(self.patches[i][j])-self.meanfeature[j]),2)
						sum_bs2+=pow((float(self.positive[n][j])-self.meanfeature[j]),2)
				cosdist=sum_ab/(math.sqrt(sum_as2)*math.sqrt(sum_bs2))
				archive.append(cosdist)						
			mean_dis=sum(archive)*1.0/len(archive)			
			out.append(str(mean_dis))			
			self.meandis.append(out)	
				
	def outdata(self):
		word=self.imf.split('_')		
		fout2=open(word[0]+'_adjcosdis.data','w')# store mean and sd of distance value for each patch.
		fout2.write('patchname mean-dis\n')
		arch=[]
		for i in range(len(self.meandis)):
			crank_idx=Rand_idx(self.meandis[i][1],i)
			arch.append(crank_idx)
		arch.sort(compare)
		for ii in arch:
			for nn in self.meandis[ii.idx]:
				fout2.write(nn+' ')
			fout2.write('\n')
		fout2.close()


						
