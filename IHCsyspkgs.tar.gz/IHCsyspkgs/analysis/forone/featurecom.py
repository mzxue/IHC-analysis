help=""" to calculate HSV, Gabor-LBP and sift features for each patch."""
import sys,os,string
import cv,cv2
from dohsvextract import *
from dogaborandlbp import *

# to calculate SIFT features
def dosift(img,outdata):
	oriimg=cv2.imread(img)
	grayone=cv2.cvtColor(oriimg,cv2.COLOR_BGR2GRAY)
	sift=cv2.SIFT()
	kp,des=sift.detectAndCompute(grayone,None)
	outf=open(outdata,'w')
	if des !=None:
		for cont in des:
			for nn in cont:
				outf.write(str(nn)+' ')
			outf.write('\n')
	else:
		for j in range(128):
			outf.write('0.0 ')
		outf.write('\n')
	outf.close()


f=open(sys.argv[1],'r')# the rgb.txt list file
cordataf=f.readlines()
feapath=''
shiftppm=[]
for i in range(len(cordataf)):
	cont=cordataf[i][:-1].split('.')
	shiftppm.append(cont[0]+'shiftsize.ppm')
	term=cont[0].split('/')
	feapath='/'.join(term[:-1])
feapath+='/'		

class feacom:
	# do feature calculation for each patch
	def __init__(self,paraf,cordatafi,shiftppmi,feapath):
		self.paraf=paraf
		self.shiftppmi=shiftppmi
		self.cordatafi=cordatafi
		self.feapath=feapath

	def getpara(self):
		# to get data from the parameter file
		f1=open(self.paraf,'r')
		data=f1.readlines()
		for i in range(len(data)):
			word=data[i][:-1].split()
			if word[0]=='Hvalue':
				self.Hvalue=word[1]
			if word[0]=='Svalue':
				self.Svalue=word[1]
			if word[0]=='Vvalue':
				self.Vvalue=word[1]
			if word[0]=='HSVscale':
				self.HSVscale=word[1]
	def HSVcal(self):
		# to calculate HSV features
		exhsv=extracthsv(self.cordatafi,self.Hvalue,self.Svalue,self.Vvalue,self.HSVscale)
		exhsv.getdata()
		exhsv.sizeshift()
		exhsv.hs_histogram()

	def Gabcal(self):
		# to calculate Gabor-LBP features
		term=self.shiftppmi.split('/')
		term2=term[-1].split('_')
		self.prefix=self.feapath+term2[0]+'_'+term2[1]
		work=gabor(self.shiftppmi,self.paraf,self.prefix)
		work.readpara()
		work.build_filters()
		work.process()
		work.lbpcompute()
		cmd='rm -rf '+self.feapath+'*ksize6grayres'
		os.system(cmd)

	def siftcal(self):
		# to calculate SIFT features
		outone=self.prefix+'_siftkpdes.txt'
		dosift(self.shiftppmi,outone)

for i in range(len(cordataf)):
	doit=feacom(sys.argv[2],cordataf[i][:-1],shiftppm[i],feapath)# the parameter file and rgbtxt list with full path
	doit.getpara()
	word=shiftppm[i].split('.')
	try:
		doit.HSVcal()
	except:		
		cmd='rm -rf '+word[0]+'*'
		os.system(cmd)
		continue
	try:
		doit.Gabcal()
	except:
		cmd='rm -rf '+doit.prefix+'*lbphist.txt'
		os.system(cmd)
		continue
	try:
		doit.siftcal()
	except:
		cmd='rm -rf '+doit.prefix+'_siftkpdes.txt'
		os.system(cmd)
		continue

