help=""" to do pca for each image data."""
import sys
from sklearn.decomposition import PCA

class comppca:
	def __init__(self,dataf,n_com,patchf):
		self.dataf=dataf
		self.n_com=n_com
		self.patchf=patchf

	def dopca(self):
		f=open(self.dataf,'r')# random1percent_features.txt
		data=f.readlines()
		matrix=[]	
		for i in range(len(data)):
			word=data[i][:-1].split()		
			archive=[]
			for nn in word[1:]:
				archive.append(float(nn))		
			matrix.append(archive)
		self.pca=PCA(n_components=int(self.n_com)) # number by training set with 99% variance, 1385 for brcc36, 773 for HER2 and 896 for ER
		self.res_dec=self.pca.fit(matrix).transform(matrix)

	def doremain(self):
		fi=open(self.patchf,'r')# allpatchfeature.txt
		test=fi.readlines()
		term=self.patchf.split('_')
		remaindata=[]
		remainname=[]
		for m in range(len(test)):
			word=test[m][:-1].split()
			remainname.append(word[0])
			archive=[]
			for nn in word[1:]:
				archive.append(float(nn))
			remaindata.append(archive)	
		res_remaint=self.pca.transform(remaindata)			
		fo2=open(term[0]+'var99_decbypca.data','w')
		outdata=[]
		for n in range(len(remainname)):
			outdata.append([])
		for n in range(len(outdata)):
			outdata[n].append(remainname[n])
			for nn in res_remaint[n]:
				outdata[n].append(str(nn))
		for j in range(len(outdata)):		
			for nn in outdata[j]:
				fo2.write(nn+' ')
			fo2.write('\n')
		fo2.close()
	
	



