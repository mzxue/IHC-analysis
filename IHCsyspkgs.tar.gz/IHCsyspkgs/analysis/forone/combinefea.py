help=""" to combine all features into a feature vector with the order of Gabor-lbp, HSV and SIFT. The final length is 20974, that is, 864 Gabor-lbp, 110 HSV and 20000 SIFT."""
import sys,string,os

class combine:
	# to combine features for each patch with the format of name gabor HSV SIFT in a line.
	def __init__(self,patchf):
		self.patchf=patchf # rgbtxt line with full path
		self.siftbound=20000 # the boundary value for sift features, and it is defined as a custom of 20000.
		word=patchf.split('.')
		term=word[0].split('/')
		prefix=term[-1].split('_')
		path='/'.join(term[:-1])
		self.feapath=path+'/'
		self.fnamepre=prefix[0]+'_'+prefix[1]

	def getgabor(self):
		self.gabpost='allfilterimg_lbphist.txt'
		self.gabfea=[]
		self.gaborf=self.feapath+self.fnamepre+self.gabpost
		if os.path.exists(self.gaborf):
			f=open(self.gaborf,'r')
			data=f.readlines()
			for i in range(len(data)):
				cont=data[i][:-1].split()
				for mm in cont[1:]:
					self.gabfea.append(mm)
	def gethsv(self):
		self.hsvpost='_rgbshiftsize2DHS-V_values_param2.txt'
		self.hsvfea=[]
		self.hsvf=self.feapath+self.fnamepre+self.hsvpost
		if os.path.exists(self.hsvf):
			f=open(self.hsvf,'r')
			f.readline()
			hs=f.readline()
			hsterm=hs[:-1].split()
			for nn in hsterm:
				self.hsvfea.append(nn)
			f.readline()
			v=f.readline()
			vterm=v[:-1].split()
			for mm in vterm:
				self.hsvfea.append(mm)

	def getsift(self):
		self.siftpost='_siftkpdes.txt'
		self.siftfea=[]
		self.siftf=self.feapath+self.fnamepre+self.siftpost
		if os.path.exists(self.siftf):
			f=open(self.siftf,'r')
			data=f.readlines()
			for i in range(len(data)):
				word=data[i][:-1].split()
				for nn in word:
					self.siftfea.append(nn)
			if len(self.siftfea)< self.siftbound:
				for m in range(len(self.siftfea),self.siftbound):
					self.siftfea.append('0.0')

f=open(sys.argv[1],'r')# the rgbtxt.list file
dataf=f.readlines()
pwd=os.getcwd()
word=dataf[0].split('/')
term=word[-2].split('_')
fout=open(pwd+'/'+term[0]+'_allpatchfeature.txt','w')
for i in range(len(dataf)):
	dowork=combine(dataf[i][:-1])
	dowork.getgabor()
	dowork.gethsv()
	dowork.getsift()
	if len(dowork.gabfea)!=0 and len(dowork.hsvfea)!=0 and len(dowork.siftfea)!=0:
		fout.write(dowork.fnamepre+' ')
		for nn in dowork.gabfea:
			fout.write(nn+' ')
		for mm in dowork.hsvfea:
			fout.write(mm+' ')
		for kk in dowork.siftfea:
			fout.write(kk+' ')
		fout.write('\n')
fout.close()
