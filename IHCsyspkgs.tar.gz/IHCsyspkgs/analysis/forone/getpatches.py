help=""" to asign each pixel into patches by rgb values and write out each patch."""
import Image,sys,os,datetime
import numpy as np
import ImageColor
from ImageColor import getrgb

class patchasign:
	def __init__(self,inppm,tarpng,bgcolor,patchdic):
		self.inppm=inppm
		self.tarpng=tarpng
		self.bgcolor=bgcolor
		self.patchdic=patchdic
		
	def readimage(self):
		self.im=Image.open(self.inppm)
		lx,ly=self.im.size
		self.mtr=np.array(self.im)
	
	def checklines(self):
		self.linebound=[]
		self.linergbs=[]
		for y in range(self.im.size[1]): # height is the line or y
			rgblines=[]
			archive=[]
			rgbarchive=[]
			for x in range(len(self.mtr[y])): # width is the column or x
				word=''
				for n in range(len(self.mtr[y][x])):
					word+=str(self.mtr[y][x][n])+' '
				rgblines.append(word)
			for p in range(len(rgblines)):
				if p != len(rgblines)-1:
					if rgblines[p]!=rgblines[p+1]:
						archive.append((p,y))
						rgbarchive.append(rgblines[p])
				else:
					continue
			self.linebound.append(archive) # only record the former pixel at the boundary.
			self.linergbs.append(rgbarchive)

	def checkcolumns(self):
		self.columnbound=[]
		self.columnrgbs=[]
		for x in range(self.im.size[0]):
			rgbcolumns=[]
			archive=[]
			rgbarchive=[]
			for y in range(len(self.mtr)):
				word=''
				for n in range(len(self.mtr[y][x])):
					word+=str(self.mtr[y][x][n])+' '
				rgbcolumns.append(word)
			for p in range(len(rgbcolumns)):
				if p != len(rgbcolumns)-1:
					if rgbcolumns[p] != rgbcolumns[p+1]:
						archive.append((x,p))
						rgbarchive.append(rgbcolumns[p])
				else:
					continue
			self.columnbound.append(archive)
			self.columnrgbs.append(rgbarchive)

	def getpatches(self):
		colbound1=[] # to make a list of 1 layer for columnbound
		rgbindexcol=[]
		for i in range(len(self.columnbound)):
			for j in range(len(self.columnbound[i])):
				colbound1.append(self.columnbound[i][j])
				rgbindexcol.append((i,j))
		linbound1=[]
		rgbindexlin=[]
		for i in range(len(self.linebound)):
			for j in range(len(self.linebound[i])):
				linbound1.append(self.linebound[i][j])
				rgbindexlin.append((i,j))

		self.patchbound=[]# make a list to store boundary points by lines. 		
		for i in range(len(self.linebound)):
			archive=[]
			for j in range(len(self.linebound[i])):
				archive.append([])
			self.patchbound.append(archive)
		
		for i in range(len(self.linebound)): # linebound[i][j] and linebound[i+1][j] will be both in patchbound[i][n] and patchbound[i+1][n], if they are belong to the same patch.
			for j in range(len(self.linebound[i])):
				for n in range(len(linbound1)):
					if self.linergbs[i][j]==self.linergbs[rgbindexlin[n][0]][rgbindexlin[n][1]]:
						self.patchbound[i][j].append(linbound1[n])
				for m in range(len(colbound1)):
					if self.linergbs[i][j]==self.columnrgbs[rgbindexcol[m][0]][rgbindexcol[m][1]]:
						if colbound1[m] not in self.patchbound[i][j]:
							self.patchbound[i][j].append(colbound1[m])

		outboundary=[]# only boundary points belong to the same patch here, repeat patch records would be removed. 
		for i in range(len(self.patchbound)):
			for j in range(len(self.patchbound[i])):
				if self.patchbound[i][j] not in outboundary:
					outboundary.append(self.patchbound[i][j])
		
		self.allpatch=[]# to store all points in a patch
		for i in range(len(outboundary)):
			self.allpatch.append([])

		for i in range(len(outboundary)): 
			for j in range(len(outboundary[i])):
				if outboundary[i][j] in self.linebound[outboundary[i][j][1]]:
					for n in range(len(self.linebound[outboundary[i][j][1]])):
						if outboundary[i][j]==self.linebound[outboundary[i][j][1]][n]:
							if n==0:
								for m in range(outboundary[i][j][0]+1):
									self.allpatch[i].append((m,outboundary[i][j][1]))
							else:
								for mn in range(self.linebound[outboundary[i][j][1]][n-1][0]+1,outboundary[i][j][0]+1):
									self.allpatch[i].append((mn,outboundary[i][j][1]))
				elif outboundary[i][j] in self.columnbound[outboundary[i][j][0]]:
					for n in range(len(self.columnbound[outboundary[i][j][0]])):
						if outboundary[i][j]==self.columnbound[outboundary[i][j][0]][n]:
							if n==0:
								for m in range(outboundary[i][j][1]+1):
									if (outboundary[i][j][0],m) not in self.allpatch[i]:
										self.allpatch[i].append((outboundary[i][j][0],m))
							else:
								for mn in range(self.columnbound[outboundary[i][j][0]][n-1][1]+1,outboundary[i][j][1]+1):
									if (outboundary[i][j][0],mn) not in self.allpatch[i]:	
										self.allpatch[i].append((outboundary[i][j][0],mn))

		tarforpatch=Image.open(self.tarpng)# the original png image
		self.patchrgb=[]
		wordname=self.tarpng.split('/')
		termname=wordname[-1].split('.')
		for i in range(len(self.allpatch)):
			archive=[]
			for j in range(len(self.allpatch[i])):
				word='rgb('
				rgbeach=tarforpatch.getpixel(self.allpatch[i][j])
				for n in range(len(rgbeach)):
					if n !=len(rgbeach)-1:
						word+=str(rgbeach[n])+','
					else:
						word+=str(rgbeach[n])+')'
				archive.append(word)
			self.patchrgb.append(archive)
		for i in range(len(self.patchrgb)):
			#newbg=Image.new('RGB',self.im.size,self.bgcolor)
			#outppm=self.patchdic+'/'+termname[0]+'_patch'+str(i)+'.ppm'
			pointdata=self.patchdic+'/'+termname[0]+'_patch'+str(i)+'position_rgb.txt'
			fout=open(pointdata,'w')
			for j in range(len(self.patchrgb[i])):
				#pixel=Image.new('RGB',(1,1),getrgb(self.patchrgb[i][j]))
				#newbg.paste(pixel,self.allpatch[i][j])
				fout.write(str(self.allpatch[i][j])+' '+self.patchrgb[i][j]+'\n')
			#newbg.save(outppm)
			fout.close()

f=open(sys.argv[1],'r') # parameter.txt
alldata=f.readlines()
for i in range(len(alldata)):
	word=alldata[i][:-1].split()
	if word[0]=='patchpath':
		patchall=word[1]
	if word[0]=='bgcolor':
		bgcolor=word[1]

word=sys.argv[2].split('.')# the superpixel.ppm file
patchdic=patchall+'/'+word[0]
cmd='mkdir '+patchall
os.system(cmd)
cmd1='mkdir '+patchdic
os.system(cmd1)
apply=patchasign(sys.argv[2],sys.argv[3],bgcolor,patchdic)# the xx.png file
apply.readimage()
apply.checklines()
apply.checkcolumns()
apply.getpatches()

