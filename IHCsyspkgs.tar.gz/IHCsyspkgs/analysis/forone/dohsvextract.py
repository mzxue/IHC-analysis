help=""" to do shift size with position-rgb files and extract hsv histogram for each patch."""
import sys,string
import Image,ImageColor
import cv
import numpy as np
from ImageColor import getrgb

class extracthsv:
	def __init__(self,posif,hbins,sbins,vbins,scale):
		#bins could be optimized, and the max value is 255 for 8-bit color images. The scale is a temporary unit for showing images. They all should be of an int type.
		self.posif=posif
		self.h_bins=hbins 	
		self.s_bins=sbins
		self.v_bins=vbins
		self.scale=scale

	def getdata(self):
		f=open(self.posif,'r')
		data=f.readlines()
		self.positions=[]
		self.rgbs=[]
		for i in range(len(data)):
			term=data[i][:-1].split(')')
			number=term[0].split('(')
			renumber=number[1].split(',')
			point=(int(renumber[0]),int(renumber[1]))
			self.positions.append(point)
			self.rgbs.append(term[1][1:]+')')
	
	def sizeshift(self):
		xall=[]
		yall=[]
		word=self.posif.split('.')
		self.outppm=word[0]+'shiftsize.ppm'
		for i in range(len(self.positions)):
			xall.append(self.positions[i][0])
			yall.append(self.positions[i][1])
		sizex=max(xall)-min(xall)
		sizey=max(yall)-min(yall)
		newimg=Image.new('RGB',(sizex+1,sizey+1))
		shiftpo=[]
		for i in range(len(self.positions)):
			newx=self.positions[i][0]-min(xall)
			newy=self.positions[i][1]-min(yall)
			newpoint=(newx,newy)
			shiftpo.append(newpoint)
		for i in range(len(shiftpo)):
			pixel=Image.new('RGB',(1,1),getrgb(self.rgbs[i]))
			newimg.paste(pixel,shiftpo[i])
		newimg.save(self.outppm)

	def hs_histogram(self):
		img=cv.LoadImage(self.outppm)
		hsv=cv.CreateImage(cv.GetSize(img),8,3)
		cv.CvtColor(img,hsv,cv.CV_BGR2HSV)# in color convert, the order is B-G-R,then asigned to H-S-V	
		h_plane=cv.CreateImage(cv.GetSize(img),8,1)
		s_plane=cv.CreateImage(cv.GetSize(img),8,1)
		v_plane=cv.CreateImage(cv.GetSize(img),8,1)
		cv.Split(hsv,h_plane,s_plane,v_plane,None) 
		planes=[h_plane,s_plane]		
		hist_size=[int(self.h_bins),int(self.s_bins)]

		# hue varies from 0 to 180 in opencv, and saturation varies from 0 to 255.
		self.h_ranges=[0,180]
		self.s_ranges=[0,255]
		self.v_ranges=[0,255]
		ranges=[self.h_ranges,self.s_ranges]
	
		# to compute the 2D HS histogram and V histogram
		hist=cv.CreateHist(hist_size,cv.CV_HIST_ARRAY,ranges,1)
		cv.CalcHist(planes,hist)
		(_,max_value,_,_)=cv.GetMinMaxHistValue(hist)
		hist_vbin=cv.CreateHist([int(self.v_bins)],cv.CV_HIST_ARRAY,[self.v_ranges],1)
		cv.CalcHist([v_plane],hist_vbin)
		(_,vmax_val,_,_)=cv.GetMinMaxHistValue(hist_vbin)

		# to show or save an image for the HSV histogram
		word=self.outppm.split('.')
		#outimg=word[0]+'HSVhist.ppm'
		outimg=word[0]+'HSVhistparam2.ppm'
		#outvaluef=word[0]+'2DHS-V_values.txt'
		outvaluef=word[0]+'2DHS-V_values_param2.txt'
		fout=open(outvaluef,'w')
		fout.write(self.h_bins+'H_bins * '+self.s_bins+'S_bins Intensity of bin values\n')
		hist_img=cv.CreateImage((int(self.h_bins)*int(self.scale),int(self.s_bins)*int(self.scale)),8,3)
		for h in range(int(self.h_bins)):
			for s in range(int(self.s_bins)):
				bin_val=cv.QueryHistValue_2D(hist,h,s)
				intensity=cv.Round(bin_val*255.0/max_value)
				fout.write(str(intensity)+' ')
				cv.Rectangle(hist_img,(h*int(self.scale),s*int(self.scale)),((h+1)*int(self.scale)-1,(s+1)*int(self.scale)-1),cv.RGB(intensity,intensity,intensity),cv.CV_FILLED)
		fout.write('\n')
		fout.write(self.v_bins+'V_bins Intensity of bin values\n')
		for v in range(int(self.v_bins)):
			vbin_val=cv.QueryHistValue_1D(hist_vbin,v)
			v_intensity=cv.Round(vbin_val*255.0/vmax_val)
			fout.write(str(v_intensity)+' ')
		fout.write('\n')
		cv.SaveImage(outimg,hist_img)

