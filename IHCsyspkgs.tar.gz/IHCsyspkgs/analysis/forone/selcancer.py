help=""" to select potential cancer patches from all patches, do PCA first then use adjusted cosine distance for similarity, and filter them by boundary values."""
import sys,os,string
import numpy as np
from pca99do import *
from adustcos2 import *

class selcan:

	def __init__(self,modelf,n_com,allpatchf,cancerpcaf):
		self.modelf=modelf
		self.n_com=n_com
		self.allpatchf=allpatchf
		self.cancerpcaf=cancerpcaf
		word=self.allpatchf.split('_')
		self.prefix=word[0]
		self.pcaresf=word[0]+'var99_decbypca.data'
		self.distf=word[0]+'var99_adjcosdis.data'
	
	def dopca(self):
		outdec=comppca(self.modelf,self.n_com,self.allpatchf)
		outdec.dopca()
		outdec.doremain()
	
	def simcal(self):
		caldis=dowork(self.pcaresf,self.cancerpcaf)
		caldis.readf()
		caldis.featuredist()
		caldis.outdata()

def filter1(prefix,distf):
	f1=open(distf,'r')# xx_adjcosdis.data file
	title=f1.readline()
	data=f1.readlines()
	hitpatch=[]
	hitcos=[]
	remainpatch=[]
	remaincos=[]
	for j in range(len(data)):
		word=data[j][:-1].split()
		if float(word[1]) >=0:
			hitpatch.append(word[0])
			hitcos.append(float(word[1]))
	if len(hitcos)==0:
		word=data[0][:-1].split()
		remainpatch.append(word[0])
		remaincos.append(word[1])
	else:
		meancos=np.mean(hitcos)
		sdcos=np.std(hitcos)
		filternum=meancos+1*sdcos
		if hitcos[0]<filternum:# histcos[0] is the maximum
			remainpatch.append(hitpatch[0])
			remaincos.append(str(hitcos[0]))
		else:
			for h in range(len(hitcos)):
				if hitcos[h]>=filternum:
					remainpatch.append(hitpatch[h])
					remaincos.append(str(hitcos[h]))
	far=open(prefix+'_potentialcancer_adjcos.dis','w')
	far.write(title)
	for n in range(len(remainpatch)):
		far.write(remainpatch[n]+' '+remaincos[n]+'\n')
	far.close()		


dowork2=selcan(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4]) # ../compound/brcc36_pca.txt 1385 xx_allpatchfeature.txt ../compound/brcc36_cancer_pcaconvt.txt; similar files in ../membrane/ 773 or ../nucleus/ 896
dowork2.dopca()
dowork2.simcal()
filter1(dowork2.prefix,dowork2.distf)


		
