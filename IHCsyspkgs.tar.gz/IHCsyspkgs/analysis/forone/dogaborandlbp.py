help=""" to do multi-scale Gabor filter for texture features."""
import cv
import sys
import cv2
import math
import os
import mahotas
import matplotlib
import numpy as np

class gabor:
	def __init__(self,imgf,paraf,prefix):
		# the most usually used value of fmax is 0.4 or math.sqrt(2)/4
		self.imgf=imgf
		self.imgarray=cv2.imread(self.imgf)
		self.paraf=paraf
		self.fmax=math.sqrt(2)/4.0
		self.prefix=prefix
		self.lbpradius=1
		self.lbppoints=8
		
	def readpara(self):
		# sigma*f=0.56, f=pow(math.sqrt(2),-k)*fmax, k in range(scale), and sigma/lamdba=0.56
		f=open(self.paraf,'r')
		data=f.readlines()
		for i in range(len(data)):
			word=data[i].split()
			if word[0]=='gaborscale':
				self.scale=int(word[1])
				self.sigmava=[]
				for s in range(self.scale):
					sigma=0.56*pow(math.sqrt(2),s)/self.fmax
					self.sigmava.append(sigma)
			elif word[0]=='orientation':
				self.orientation=int(word[1])
			elif word[0]=='gamma':
				self.gamma=float(word[1])
			elif word[0]=='psiangle':
				self.psi=(int(word[1])-180)*np.pi/180
			elif word[0]=='kernel_size':
				self.ksize=int(word[1])
		self.lambdaval=[]
		for i in range(len(self.sigmava)):
			lambdava=self.sigmava[i]/0.56
			self.lambdaval.append(lambdava)
	
	def build_filters(self):
		# build a list of kernels in several scales and several orientations.
		self.filters=[]
		ktype=cv2.CV_32F
		for sig in range(len(self.sigmava)):
			for theta in np.arange(0,np.pi,np.pi/self.orientation):
				params={'ksize':(self.ksize,self.ksize),'sigma':self.sigmava[sig],'theta':theta,'lambd':self.lambdaval[sig],'gamma':self.gamma,'psi':self.psi,'ktype':ktype}
				kern=cv2.getGaborKernel(**params)
				newkern=kern/(1.5*kern.sum())
				self.filters.append((newkern,params))

	def process(self):
		# return the img filtered by the filted list
		self.accum=np.zeros_like(self.imgarray)
		count=0
		self.filterimgdata=[]
		self.filterimgfname=[]
		newpath=self.prefix+'ksize'+str(self.ksize)+'grayres'
		cmd='mkdir '+newpath
		os.system(cmd)
		for kern,params in self.filters:
			count+=1
			fimg=cv2.filter2D(self.imgarray,cv2.CV_8UC3,kern)# use filter to deal with the original image 
			np.maximum(self.accum,fimg,self.accum)
			newgrey=cv2.cvtColor(fimg,cv2.COLOR_BGR2GRAY)
			newaccum=cv2.cvtColor(self.accum,cv2.COLOR_BGR2GRAY)
			self.filterimgdata.append(newgrey)
			greyfname=newpath+'/kernel'+str(self.ksize)+'res'+str(count)+'_filtered_gray.pgm'
			self.filterimgfname.append(greyfname)
			cv2.imwrite(newpath+'/kernel'+str(self.ksize)+'res'+str(count)+'_filtered_gray.pgm',newgrey)
			cv2.imwrite(newpath+'/'+newpath+str(count)+'_accum_gray.pgm',newaccum)

	def lbpcompute(self):
		outdataf=open(self.prefix+'allfilterimg_lbphist.txt','w')
		for i in range(len(self.filterimgdata)):
			histdata=mahotas.features.lbp(self.filterimgdata[i],self.lbpradius,self.lbppoints)
			sumpixel=histdata.sum()
			normdata=[]
			word=self.filterimgfname[i].split('_')
			outdataf.write(word[0]+' ')
			for j in range(len(histdata)):
				frequent=histdata[j]*100.0/sumpixel
				normdata.append(frequent)
			for cont in normdata:
				outdataf.write(str(cont)+' ')
			outdataf.write('\n')
		outdataf.close()


